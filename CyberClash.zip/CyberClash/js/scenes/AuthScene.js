// Auth Scene
        class AuthScene extends Phaser.Scene {
            constructor() {
                super('AuthScene');
            }

            create() {
                const { width, height } = this.cameras.main;

                this.add.rectangle(0, 0, width, height, 0x0f1419).setOrigin(0);

                this.add.text(width / 2, 150, 'Choose Your Path', {
                    fontFamily: 'Orbitron',
                    fontSize: '48px',
                    fontWeight: 'bold',
                    color: '#00ff88'
                }).setOrigin(0.5);

                this.add.text(width / 2, 220, 'Demo complete! Ready for more battles?', {
                    fontFamily: 'Rajdhani',
                    fontSize: '22px',
                    color: '#aaaaaa'
                }).setOrigin(0.5);

                const anonBtn = this.add.rectangle(width / 2, height / 2 - 80, 550, 90, 0x334455)
                    .setInteractive({ useHandCursor: true });
                
                this.add.text(width / 2, height / 2 - 105, '🎮 Continue Anonymous', {
                    fontFamily: 'Rajdhani',
                    fontSize: '30px',
                    fontWeight: 'bold',
                    color: '#ffffff'
                }).setOrigin(0.5);

                this.add.text(width / 2, height / 2 - 65, 'Quick play, no account needed', {
                    fontFamily: 'Rajdhani',
                    fontSize: '18px',
                    color: '#aaaaaa'
                }).setOrigin(0.5);

                anonBtn.on('pointerdown', () => {
                    gameState.isAnonymous = true;
                    gameState.hasCompletedDemo = true;
                    this.scene.start('BattleScene', { isDemo: false, duration: 60 });
                });

                anonBtn.on('pointerover', () => anonBtn.setFillStyle(0x445566));
                anonBtn.on('pointerout', () => anonBtn.setFillStyle(0x334455));

                const profileBtn = this.add.rectangle(width / 2, height / 2 + 80, 550, 90, 0x00ff88)
                    .setInteractive({ useHandCursor: true });
                
                this.add.text(width / 2, height / 2 + 55, '👤 Create Gamer Profile', {
                    fontFamily: 'Rajdhani',
                    fontSize: '30px',
                    fontWeight: 'bold',
                    color: '#001111'
                }).setOrigin(0.5);

                this.add.text(width / 2, height / 2 + 95, 'Track progress, save achievements', {
                    fontFamily: 'Rajdhani',
                    fontSize: '18px',
                    color: '#003333'
                }).setOrigin(0.5);

                profileBtn.on('pointerdown', () => {
                    if (auth) {
                        this.scene.start('LoginScene');
                    } else {
                        this.showFirebaseWarning();
                    }
                });

                profileBtn.on('pointerover', () => profileBtn.setFillStyle(0x00dd77));
                profileBtn.on('pointerout', () => profileBtn.setFillStyle(0x00ff88));
            }

            showFirebaseWarning() {
                const { width, height } = this.cameras.main;
                
                const overlay = this.add.rectangle(0, 0, width, height, 0x000000, 0.8).setOrigin(0).setInteractive();
                const box = this.add.rectangle(width / 2, height / 2, 650, 320, 0x1a1f2e);
                
                const text = this.add.text(width / 2, height / 2 - 60, 'Firebase Not Configured', {
                    fontFamily: 'Orbitron',
                    fontSize: '28px',
                    fontWeight: 'bold',
                    color: '#ff4444'
                }).setOrigin(0.5);

                const info = this.add.text(width / 2, height / 2 + 20, 'Please set up Firebase to use authentication.\nContinue as anonymous for now.', {
                    fontFamily: 'Rajdhani',
                    fontSize: '20px',
                    color: '#ffffff',
                    align: 'center',
                    lineSpacing: 10
                }).setOrigin(0.5);

                const okBtn = this.add.rectangle(width / 2, height / 2 + 110, 220, 60, 0x00ff88)
                    .setInteractive({ useHandCursor: true });
                
                this.add.text(width / 2, height / 2 + 110, 'OK', {
                    fontFamily: 'Orbitron',
                    fontSize: '24px',
                    fontWeight: 'bold',
                    color: '#001111'
                }).setOrigin(0.5);

                okBtn.on('pointerdown', () => {
                    overlay.destroy();
                    box.destroy();
                    text.destroy();
                    info.destroy();
                    okBtn.destroy();
                });
            }
        }