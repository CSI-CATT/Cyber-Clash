// Firebase Configuration (USER NEEDS TO REPLACE WITH THEIR CONFIG)
        const firebaseConfig = {
            apiKey: "YOUR_API_KEY",
            authDomain: "YOUR_PROJECT.firebaseapp.com",
            projectId: "YOUR_PROJECT_ID",
            storageBucket: "YOUR_PROJECT.appspot.com",
            messagingSenderId: "YOUR_SENDER_ID",
            appId: "YOUR_APP_ID"
        };

        // Initialize Firebase (will be null if config not set)
        let firebaseApp = null;
        let auth = null;
        try {
            if (firebaseConfig.apiKey !== "YOUR_API_KEY") {
                firebaseApp = firebase.initializeApp(firebaseConfig);
                auth = firebase.auth();
            }
        } catch (e) {
            console.log("Firebase not configured yet");
        }