// Game state storage (using in-memory storage)
const gameState = {
  isAnonymous: false,
  hasCompletedDemo: false,
  userId: null,
  username: null,
  seenCardTutorials: {}
};

// Global data variables
let CARDS = {};
let QUIZ_QUESTIONS = [];

// Load external data before starting game
Promise.all([
  fetch("data/cards.json").then(res => res.json()),
  fetch("data/quiz.json").then(res => res.json())
])
  .then(([cards, quiz]) => {
    CARDS = cards;
    QUIZ_QUESTIONS = quiz;

    console.log("Cards loaded:", CARDS);
    console.log("Quiz loaded:", QUIZ_QUESTIONS);

    // Game Configuration
    const config = {
      type: Phaser.AUTO,
      width: 800,
      height: 1200,
      parent: "game-container",
      physics: {
        default: "arcade",
        arcade: {
          gravity: { y: 0 },
          debug: false
        }
      },
      scale: {
        mode: Phaser.Scale.FIT,
        autoCenter: Phaser.Scale.CENTER_BOTH
      },
      scene: [LoadingScene, WelcomeScene, AuthScene, LoginScene, BattleScene, ResultScene]
    };

    // Start Phaser game AFTER data is loaded
    new Phaser.Game(config);
  })
  .catch(err => console.error("Error loading game data:", err));
