// Login Scene
        class LoginScene extends Phaser.Scene {
            constructor() {
                super('LoginScene');
            }

            create() {
                const { width, height } = this.cameras.main;

                this.add.rectangle(0, 0, width, height, 0x0f1419).setOrigin(0);

                this.add.text(width / 2, 200, 'Sign In', {
                    fontFamily: 'Orbitron',
                    fontSize: '56px',
                    fontWeight: 'bold',
                    color: '#00ff88'
                }).setOrigin(0.5);

                this.add.text(width / 2, 350, 'Email: [Input Field]', {
                    fontFamily: 'Rajdhani',
                    fontSize: '24px',
                    color: '#ffffff'
                }).setOrigin(0.5);

                this.add.text(width / 2, 420, 'Password: [Input Field]', {
                    fontFamily: 'Rajdhani',
                    fontSize: '24px',
                    color: '#ffffff'
                }).setOrigin(0.5);

                const signInBtn = this.add.rectangle(width / 2, 550, 350, 70, 0x00ff88)
                    .setInteractive({ useHandCursor: true });
                
                this.add.text(width / 2, 550, 'SIGN IN', {
                    fontFamily: 'Orbitron',
                    fontSize: '28px',
                    fontWeight: 'bold',
                    color: '#001111'
                }).setOrigin(0.5);

                signInBtn.on('pointerdown', () => {
                    gameState.userId = 'user_' + Date.now();
                    gameState.username = 'Player_' + Math.floor(Math.random() * 1000);
                    this.scene.start('BattleScene', { isDemo: false, duration: 60 });
                });

                const backBtn = this.add.rectangle(width / 2, 650, 350, 70, 0x334455)
                    .setInteractive({ useHandCursor: true });
                
                this.add.text(width / 2, 650, 'BACK', {
                    fontFamily: 'Rajdhani',
                    fontSize: '24px',
                    color: '#ffffff'
                }).setOrigin(0.5);

                backBtn.on('pointerdown', () => {
                    this.scene.start('AuthScene');
                });
            }
        }